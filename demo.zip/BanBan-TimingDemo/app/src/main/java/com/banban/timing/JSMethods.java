package com.banban.timing;

import android.content.Context;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.banban.timing.utils.SPUtils;

import org.json.JSONException;
import org.json.JSONObject;


/**
 * js交互的方法
 *
 * @author Admin
 */
public class JSMethods {
    private WebView mWebView;
    private Context mContext;

    public JSMethods(Context context, WebView webView) {
        this.mContext = context;
        this.mWebView = webView;
    }

    /**
     * 给js传递参数
     */
    @JavascriptInterface
    public String getParam() {
        try {
            JSONObject json = new JSONObject();
            json.put("token", SPUtils.getString(mContext, "token"));
            return json.toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 关闭页面
     */
    @JavascriptInterface
    public void closeWindows() {
        if (mContext instanceof WebviewActivity) {
            WebviewActivity webviewActivity = (WebviewActivity) mContext;
            if (!webviewActivity.isFinishing()) {
                webviewActivity.finish();
            }
        }
    }

    /**
     * 是否禁用返回键
     */
    @JavascriptInterface
    public void disableBack(boolean disable) {
        if (mContext instanceof WebviewActivity) {
            WebviewActivity webviewActivity = (WebviewActivity) mContext;
            webviewActivity.disableBack(disable);
        }
    }



}
