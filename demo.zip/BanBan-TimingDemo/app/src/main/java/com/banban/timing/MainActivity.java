package com.banban.timing;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.banban.timing.utils.SPUtils;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.apache.http.Header;
import org.json.JSONException;
import org.json.JSONObject;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity
        extends AppCompatActivity
        implements View.OnClickListener
{
    private Button message, timing;
    private String   token;
    private EditText idNum;
    private EditText name;
    private EditText phone;
    private EditText schoolNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }


    private void init() {
        message = (Button) findViewById(R.id.message);
        timing = (Button) findViewById(R.id.timing);
        message.setOnClickListener(this);
        timing.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.timing) {
            if (token == null) {
                Toast.makeText(MainActivity.this, "请先获取token", Toast.LENGTH_SHORT)
                     .show();
            } else {
                Intent intent = new Intent(this, WebviewActivity.class);
                startActivity(intent);
            }
        } else if (v.getId() == R.id.message) {
            showGetTokenDialog();
        }

    }


    private String getToken() {

        String name      = this.name.getText().toString().trim();
        String idNum     = this.idNum.getText().toString().trim();
        String phone     = this.phone.getText().toString().trim();
        String schoolNum = this.schoolNum.getText().toString().trim();

        RequestParams rParams = new RequestParams();
        rParams.setUseJsonStreamer(true);
        rParams.put("account", TextUtils.isEmpty(phone) ? "13570366144" : phone);
        rParams.put("idNumber", TextUtils.isEmpty(idNum) ? "345435345213423423" : idNum);
        rParams.put("schoolCode", TextUtils.isEmpty(schoolNum) ? "TESTCODE0001" : schoolNum);
        rParams.put("userName", TextUtils.isEmpty(name) ? "吴小全" : name);

        AsyncHttpClient asyncHttpclient = new AsyncHttpClient();
        String          url             = "http://app.chetailian.net/api/user/outer/test/v1/testGetToken.pass";
        asyncHttpclient.post(this, url, rParams, new AsyncHttpResponseHandler() {
            private String id;

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseByte) {
                String successStr = new String(responseByte);
                try {
                    JSONObject jObject = new JSONObject(successStr);
                    boolean    status  = jObject.getBoolean("status");
                    if (status) {
                        JSONObject rObject = jObject.getJSONObject("result");

                        token = rObject.getString("ctl-token");
                        SPUtils.put(MainActivity.this, "token", token);
                        Toast.makeText(MainActivity.this, "token获取成功", Toast.LENGTH_SHORT)
                             .show();
                        Log.e("TAG", "token=" + token);
                        return;
                    }

                    String error_message = jObject.getString("message");
                    Log.e("TAG", "error：" + error_message);

                    Toast.makeText(MainActivity.this, "获取失败", Toast.LENGTH_SHORT)
                         .show();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                if (responseBody != null) {
                    String s = new String(responseBody);
                    try {
                        JSONObject jsonObject    = new JSONObject(s);
                        String     error_message = jsonObject.getString("message");
                        Log.e("TAG", "error：" + error_message);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                Toast.makeText(MainActivity.this, "获取失败", Toast.LENGTH_SHORT)
                     .show();

            }
        });
        return token;
    }

    protected void showGetTokenDialog() {
        AlertDialog.Builder builder  = new AlertDialog.Builder(this);
        LayoutInflater      inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View          root     = inflater.inflate(R.layout.dialog_setting, null);

        idNum = (EditText) root.findViewById(R.id.idNum);
        name = (EditText) root.findViewById(R.id.name);
        phone = (EditText) root.findViewById(R.id.phone);
        schoolNum = (EditText) root.findViewById(R.id.schoolNum);

        builder.setTitle(getString(R.string.s1));
        builder.setView(root);
        final AlertDialog dialog = builder.create();

        dialog.setCancelable(false);
        dialog.setButton(DialogInterface.BUTTON_POSITIVE, getString(R.string.dlg_ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                getToken();

            }
        });
        dialog.setButton(DialogInterface.BUTTON_NEGATIVE, getString(R.string.dlg_cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        dialog.show();
    }


}
